#!/bin/bash
set -euo pipefail

if [ "$(uname -s)" != "Darwin" ]; then
    echo "需要在安装了 Xcode 16 或更新版本的 Mac 上运行此脚本。" >&2
    exit 2
fi
if ! command -v xcodebuild >/dev/null || ! command -v swift >/dev/null; then
    echo "请先安装并选择完整的 Xcode 开发环境。" >&2
    exit 2
fi

cd "$(dirname "$0")/.."
project_root="$PWD"
output_dir="${1:-$project_root/.build/ipa}"
mkdir -p "$output_dir"
output_dir="$(cd "$output_dir" && pwd)"
derived_data="$project_root/.build/iphone-device"

swift test
xcodebuild -project StylePort.xcodeproj -scheme StylePort \
    -configuration Release \
    -destination 'generic/platform=iOS' \
    -derivedDataPath "$derived_data" \
    CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" build

staging_dir="$(mktemp -d "${TMPDIR:-/tmp}/photo-style-ipa.XXXXXX")"
trap 'rm -rf "$staging_dir"' EXIT
mkdir -p "$staging_dir/Payload"
ditto "$derived_data/Build/Products/Release-iphoneos/StylePort.app" \
    "$staging_dir/Payload/StylePort.app"
(
    cd "$staging_dir"
    /usr/bin/zip -qry "$staging_dir/PhotoStyle-unsigned.ipa" Payload
)
mv -f "$staging_dir/PhotoStyle-unsigned.ipa" "$output_dir/PhotoStyle-unsigned.ipa"
echo "已生成：$output_dir/PhotoStyle-unsigned.ipa"
echo "这是未签名 IPA，安装到 iPhone 前仍需使用自己的签名。"
