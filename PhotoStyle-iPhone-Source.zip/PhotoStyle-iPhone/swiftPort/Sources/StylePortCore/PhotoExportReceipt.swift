import Foundation

/// A successfully saved copy and the original it came from. No receipt is created until
/// PhotoKit's save transaction has completed successfully.
public struct ExportedPhoto: Sendable, Equatable {
    public let originalIdentifier: String
    public let savedIdentifier: String
    public let preservesOriginalContent: Bool
    public let requiresLivePhoto: Bool

    public init(
        originalIdentifier: String,
        savedIdentifier: String,
        preservesOriginalContent: Bool,
        requiresLivePhoto: Bool
    ) {
        self.originalIdentifier = originalIdentifier
        self.savedIdentifier = savedIdentifier
        self.preservesOriginalContent = preservesOriginalContent
        self.requiresLivePhoto = requiresLivePhoto
    }
}

/// Completion of one explicit Export action, including partial failures.
public struct PhotoExportReceipt: Identifiable, Sendable {
    public let id: UUID
    public let requestedCount: Int
    public let photos: [ExportedPhoto]
    public let failures: [String]

    public init(id: UUID, requestedCount: Int, photos: [ExportedPhoto], failures: [String]) {
        self.id = id
        self.requestedCount = requestedCount
        self.photos = photos
        self.failures = failures
    }

    /// Never propose deleting failed exports, incomplete Live Photos or originals whose
    /// existing Photos edits were not transferred. Reject ambiguous identifier mappings.
    public var deletionCandidates: [ExportedPhoto] {
        let originals = Set(photos.map(\.originalIdentifier))
        let copies = Set(photos.map(\.savedIdentifier))
        guard originals.isDisjoint(with: copies), copies.count == photos.count else { return [] }
        var seen = Set<String>()
        return photos.filter {
            !$0.originalIdentifier.isEmpty && !$0.savedIdentifier.isEmpty
                && $0.preservesOriginalContent
                && seen.insert($0.originalIdentifier).inserted
        }
    }
}
