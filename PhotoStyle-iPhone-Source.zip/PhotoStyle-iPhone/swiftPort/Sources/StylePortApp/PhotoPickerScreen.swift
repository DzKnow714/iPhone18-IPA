import Photos
import SwiftUI

/// Opens directly on the library. Selection order is shown as blue numbered tiles.
struct PhotoPickerScreen: View {
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var queue: PortQueue
    @StateObject private var model = AssetListModel(scope: .library, sort: .saved, ascending: false)
    @StateObject private var albums = AlbumsModel()
    @State private var access = PhotoLibraryService.status
    @State private var selectedIDs: [String] = []
    @State private var selectedAssets: [PHAsset] = []
    @State private var albumTitle = "最近项目"
    @State private var showsAdjustment = false
    @State private var showsSettings = false
    @State private var unsupportedPhoto = false

    private let columns = Array(repeating: GridItem(.flexible(), spacing: 1), count: 4)

    var body: some View {
        NavigationStack {
            library
                .background(Color(uiColor: .systemBackground))
                .navigationBarTitleDisplayMode(.inline)
                .toolbarBackground(.visible, for: .navigationBar)
                .toolbar {
                    ToolbarItem(placement: .principal) { albumMenu }
                    ToolbarItem(placement: .topBarTrailing) {
                        Button { showsSettings = true } label: {
                            Image(systemName: "gearshape.fill")
                                .font(.title3)
                                .foregroundStyle(.primary)
                        }
                        .accessibilityLabel("设置")
                    }
                }
                .safeAreaInset(edge: .bottom, spacing: 0) { adjustmentBar }
                .navigationDestination(isPresented: $showsAdjustment) {
                    PhotoAdjustScreen(assets: selectedAssets) {
                        selectedIDs.removeAll()
                        selectedAssets.removeAll()
                        showsAdjustment = false
                        model.reload()
                    }
                }
                .sheet(isPresented: $showsSettings) { PhotoFlowSettings() }
                .alert("暂不支持这张照片", isPresented: $unsupportedPhoto) {
                    Button("好", role: .cancel) { }
                } message: {
                    Text("请选择 iPhone 拍摄的 HEIC 原图。JPEG、截图等格式暂时无法添加摄影风格。")
                }
        }
        .tint(.blue)
        .task { await refreshAccess() }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { Task { await refreshAccess() } }
        }
    }

    @ViewBuilder
    private var library: some View {
        if access == .authorized || access == .limited {
            ScrollView {
                LazyVGrid(columns: columns, spacing: 1) {
                    ForEach(model.assets, id: \.localIdentifier) { asset in
                        Button { toggle(asset) } label: {
                            pickerTile(asset)
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("选择照片")
                        .accessibilityValue(selectionNumber(asset).map { "已选，第 \($0) 张" } ?? "未选择")
                    }
                }
            }
            .overlay {
                if model.isLoading {
                    ProgressView("正在读取照片…")
                } else if model.assets.isEmpty {
                    ContentUnavailableView {
                        Label("暂无照片", systemImage: "photo.on.rectangle")
                    } description: {
                        Text(access == .limited ? "选择允许访问的照片后，即可开始调整。" : "保存照片到相册后，会显示在这里。")
                    } actions: {
                        if access == .limited {
                            Button("选择照片") { LimitedLibrary.presentPicker() }
                                .buttonStyle(.borderedProminent)
                        }
                    }
                }
            }
        } else if access == .notDetermined {
            ProgressView("正在打开相册…")
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else {
            ContentUnavailableView {
                Label("允许访问照片", systemImage: "photo.badge.plus")
            } description: {
                Text("在系统设置中允许访问照片，即可选择原图进行调整。")
            } actions: {
                Button("前往设置") { LimitedLibrary.openSettings() }
                    .buttonStyle(.borderedProminent)
            }
        }
    }

    private var albumMenu: some View {
        Menu {
            Button("最近项目") { showAlbum(nil) }
            if !albums.myAlbums.isEmpty {
                Section("我的相簿") {
                    ForEach(albums.myAlbums) { album in
                        Button(album.title) { showAlbum(album) }
                    }
                }
            }
            if !albums.mediaTypes.isEmpty {
                Section("照片类型") {
                    ForEach(albums.mediaTypes) { album in
                        Button(album.title) { showAlbum(album) }
                    }
                }
            }
            if access == .limited {
                Button("选择更多照片…") { LimitedLibrary.presentPicker() }
            }
        } label: {
            HStack(spacing: 5) {
                Text(albumTitle).font(.headline)
                Image(systemName: "chevron.down").font(.caption.weight(.semibold))
            }
            .foregroundStyle(.primary)
        }
        .disabled(access != .authorized && access != .limited)
    }

    private func pickerTile(_ asset: PHAsset) -> some View {
        Color.clear
            .aspectRatio(1, contentMode: .fit)
            .overlay { AssetImage(asset: asset) }
            .clipped()
            .overlay {
                if selectionNumber(asset) != nil { Color.blue.opacity(0.62) }
            }
            .overlay(alignment: .topLeading) {
                if let number = selectionNumber(asset) {
                    Text("\(number)")
                        .font(.system(size: 26, weight: .medium))
                        .foregroundStyle(.white)
                        .padding(7)
                }
            }
            .overlay(alignment: .bottomLeading) {
                if asset.mediaSubtypes.contains(.photoLive) {
                    Image(systemName: "livephoto")
                        .font(.caption)
                        .foregroundStyle(.white)
                        .shadow(radius: 2)
                        .padding(5)
                }
            }
            .contentShape(Rectangle())
    }

    private var adjustmentBar: some View {
        ZStack {
            Button("调整") { openAdjustment() }
                .font(.headline)
                .frame(maxWidth: .infinity, minHeight: 60)
                .disabled(selectedIDs.isEmpty || queue.isRunning)
                .opacity(selectedIDs.isEmpty ? 0.55 : 1)
            HStack {
                Button { selectedIDs.removeAll() } label: {
                    Image(systemName: "xmark")
                        .font(.title3)
                        .frame(width: 48, height: 60)
                }
                .accessibilityLabel("清空选择")
                .disabled(selectedIDs.isEmpty)
                Spacer()
                if !selectedIDs.isEmpty {
                    Text("\(selectedIDs.count)")
                        .font(.subheadline.monospacedDigit())
                        .padding(.trailing, 20)
                        .allowsHitTesting(false)
                }
            }
        }
        .foregroundStyle(.white)
        .background(Color.blue.ignoresSafeArea(edges: .bottom))
    }

    private func selectionNumber(_ asset: PHAsset) -> Int? {
        selectedIDs.firstIndex(of: asset.localIdentifier).map { $0 + 1 }
    }

    private func toggle(_ asset: PHAsset) {
        guard !queue.isRunning else { return }
        if let index = selectedIDs.firstIndex(of: asset.localIdentifier) {
            selectedIDs.remove(at: index)
        } else if PhotoLibraryService.isHEIC(asset) {
            selectedIDs.append(asset.localIdentifier)
        } else {
            unsupportedPhoto = true
        }
    }

    private func openAdjustment() {
        let result = PHAsset.fetchAssets(withLocalIdentifiers: selectedIDs, options: nil)
        var byID: [String: PHAsset] = [:]
        result.enumerateObjects { asset, _, _ in byID[asset.localIdentifier] = asset }
        selectedAssets = selectedIDs.compactMap { byID[$0] }
        if !selectedAssets.isEmpty { showsAdjustment = true }
    }

    private func showAlbum(_ album: AlbumItem?) {
        let collection = album.flatMap {
            PHAssetCollection.fetchAssetCollections(withLocalIdentifiers: [$0.id], options: nil).firstObject
        }
        albumTitle = album?.title ?? "最近项目"
        model.showCollection(collection)
    }

    private func refreshAccess() async {
        access = await PhotoLibraryService.requestAccess()
        if access == .authorized || access == .limited {
            model.load()
            albums.load()
        }
    }
}

struct PhotoFlowSettings: View {
    @Environment(\.dismiss) private var dismiss
    @AppStorage(AppSettings.analyzePhotoKey) private var analyzePhoto = true
    @AppStorage(AppSettings.textureKey) private var texture = true

    var body: some View {
        NavigationStack {
            Form {
                Section("调整选项") {
                    Toggle("智能分析照片", isOn: $analyzePhoto)
                    Toggle("添加质感与颗粒", isOn: $texture)
                }
                Section {
                    Text("开启智能分析后，根据照片本身的明暗生成调色信息。质感与颗粒需要 iOS 27 才能在系统相册中调整。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                Section("导出") {
                    Text("处理结果保存到系统相册后，会询问是否删除原图。")
                    if PhotoLibraryService.status == .limited {
                        Button("管理允许访问的照片") { LimitedLibrary.presentPicker() }
                    }
                }
                Section {
                    Link("开源项目 Shalielie", destination: AppSettings.repositoryURL)
                    LabeledContent("版本", value: AppSettings.appVersion)
                }
            }
            .navigationTitle("设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
        .tint(.blue)
    }
}
