import Photos
import StylePortCore
import SwiftUI

/// A full-photo preview with Export at the bottom, followed by the original-deletion prompt.
struct PhotoAdjustScreen: View {
    let assets: [PHAsset]
    let onFinished: () -> Void

    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var queue: PortQueue
    @State private var page = 0
    @State private var expectedExportID: UUID?
    @State private var showsSettings = false
    @State private var deleting = false
    @State private var hasExported = false
    @State private var notice: Notice?

    private enum Notice: Identifiable {
        case exported(PhotoExportReceipt)
        case deletionFailed(UUID, String)

        var id: UUID {
            switch self {
            case .exported(let receipt): return receipt.id
            case .deletionFailed(let id, _): return id
            }
        }
    }

    private var working: Bool { expectedExportID != nil || deleting }

    var body: some View {
        VStack(spacing: 0) {
            TabView(selection: $page) {
                ForEach(assets.indices, id: \.self) { index in
                    AssetImage(asset: assets[index], contentMode: .fit)
                        .tag(index)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            if assets.count > 1 {
                Text("\(page + 1) / \(assets.count)")
                    .font(.footnote.monospacedDigit())
                    .foregroundStyle(.secondary)
                    .padding(.vertical, 10)
            }
        }
        .background(Color(uiColor: .systemBackground))
        .navigationBarBackButtonHidden(true)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button { dismiss() } label: {
                    Image(systemName: "chevron.left")
                        .font(.title3.weight(.medium))
                        .foregroundStyle(.primary)
                }
                .accessibilityLabel("返回选照片")
                .disabled(working)
            }
            ToolbarItem(placement: .principal) { Text("调整").font(.headline) }
            ToolbarItem(placement: .topBarTrailing) {
                Button { showsSettings = true } label: {
                    Image(systemName: "slider.horizontal.3")
                        .font(.title3)
                        .foregroundStyle(.primary)
                }
                .accessibilityLabel("调整选项")
                .disabled(working)
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) { exportBar }
        .sheet(isPresented: $showsSettings) { PhotoFlowSettings() }
        .alert(item: $notice, content: makeAlert)
        .onChange(of: queue.exportReceipt?.id) { _, _ in
            guard let receipt = queue.exportReceipt, receipt.id == expectedExportID else { return }
            expectedExportID = nil
            hasExported = !receipt.photos.isEmpty
            notice = .exported(receipt)
        }
    }

    private var exportBar: some View {
        VStack(spacing: 12) {
            if working {
                Text(deleting ? "正在删除原图…" : exportProgress)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            } else {
                Text("导出后，可在系统相册中调整摄影风格")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            Button {
                expectedExportID = queue.export(assets)
            } label: {
                HStack(spacing: 9) {
                    if working { ProgressView().tint(.white) }
                    Text(working ? "请稍候" : "导出")
                        .font(.headline)
                }
                .frame(maxWidth: .infinity, minHeight: 54)
                .foregroundStyle(.white)
                .background(Color.blue, in: RoundedRectangle(cornerRadius: 12))
            }
            .buttonStyle(.plain)
            .disabled(working || queue.isRunning || hasExported || assets.isEmpty)
            .opacity(hasExported ? 0.55 : 1)
        }
        .padding(.horizontal, 16)
        .padding(.top, 14)
        .padding(.bottom, 12)
        .background(.bar)
    }

    private var exportProgress: String {
        let ids = Set(assets.map(\.localIdentifier))
        let jobs = queue.jobs.filter { $0.assetIdentifier.map(ids.contains) ?? false }
        let finished = jobs.filter(\.isFinished).count
        return "正在导出 \(min(finished + 1, assets.count)) / \(assets.count)…"
    }

    private func makeAlert(_ notice: Notice) -> Alert {
        switch notice {
        case .deletionFailed(_, let message):
            return Alert(
                title: Text("删除未完成"),
                message: Text("导出的照片已保存。\n\(message)"),
                dismissButton: .default(Text("完成"), action: onFinished)
            )
        case .exported(let receipt):
            let canDelete = !receipt.deletionCandidates.isEmpty
            let title = receipt.photos.isEmpty ? "导出失败" : (canDelete ? "是否删除原图？" : "导出完成")
            if canDelete {
                return Alert(
                    title: Text(title),
                    message: Text(completionText(receipt)),
                    primaryButton: .cancel(Text("保留原图"), action: onFinished),
                    secondaryButton: .destructive(Text("删除原图")) {
                        deleting = true
                        Task { await deleteOriginals(receipt) }
                    }
                )
            }
            return Alert(
                title: Text(title),
                message: Text(completionText(receipt)),
                dismissButton: .default(Text(receipt.photos.isEmpty ? "好" : "完成")) {
                    if !receipt.photos.isEmpty { onFinished() }
                }
            )
        }
    }

    private func completionText(_ receipt: PhotoExportReceipt) -> String {
        var lines: [String] = []
        if !receipt.photos.isEmpty { lines.append("已导出 \(receipt.photos.count) 张照片到相册。") }
        if !receipt.failures.isEmpty {
            lines.append("\(receipt.failures.count) 张导出失败，原图已保留。")
            lines.append(contentsOf: receipt.failures.prefix(2))
        }
        let protected = receipt.photos.count - receipt.deletionCandidates.count
        if protected > 0 {
            lines.append("\(protected) 张原图包含已有编辑或未完整保留实况，已为你保留。")
        }
        if !receipt.deletionCandidates.isEmpty {
            let count = receipt.deletionCandidates.count
            lines.append("是否删除这 \(count) 张已完整导出的照片的原图？")
        }
        return lines.joined(separator: "\n")
    }

    private func deleteOriginals(_ receipt: PhotoExportReceipt) async {
        do {
            _ = try await PhotoLibraryService().deleteOriginals(after: receipt)
            deleting = false
            onFinished()
        } catch {
            deleting = false
            notice = .deletionFailed(UUID(), error.localizedDescription)
        }
    }
}
