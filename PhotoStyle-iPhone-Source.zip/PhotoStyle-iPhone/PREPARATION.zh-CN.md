# iPhone APP 代码准备记录

当前阶段：已根据两张参考截图实现简洁界面和导出流程源码，等待原生编译和真机验证。

## 源码基线

| 项目 | 位置或版本 |
| --- | --- |
| 上游仓库 | https://github.com/nathanatgit/Shalielie |
| Python / Web 主分支 | `../Shalielie/`，提交 `f95f832eb9f63286eba7b1748d8d9223f168b03a` |
| 原生 iOS 分支 | `agent/swift-port`，提交 `f2bd324c1ce81501e19bde54c0aa280b0a109d4f` |
| 本地开发分支 | `codex/iphone-ui` |
| iOS 工程 | `swiftPort/StylePort.xcodeproj` |
| Python 命令行版本 | `0.7.0` |
| Swift 核心声明版本 | `0.6.3-swift`；原生分支另含 Live Photo 支持 |
| 许可 | MIT；后续分发保留上游版权和许可 |

## 界面接入位置

| 功能 | 文件或入口 |
| --- | --- |
| APP 启动和根界面 | `swiftPort/Sources/StylePortApp/StylePortApp.swift` |
| 照片处理核心 | `swiftPort/Sources/StylePortCore/StylePorter.swift`：`StylePorter.patch(_:options:)` |
| 可处理性判断 | `StylePorter.eligibility(of:)` |
| 从相册选取并处理 | `swiftPort/Sources/StylePortApp/PortQueue.swift`：`port(_ assets:)` |
| 从文件导入并处理 | 同一文件：`port(files:)` |
| 相册权限、读取原图、保存结果 | `swiftPort/Sources/StylePortApp/PhotoLibraryService.swift` |
| 实况照片处理 | `LivePhotoStyler.swift` 和核心中的 `LivePhotoVideo.swift` |
| 参数与保存方式 | `swiftPort/Sources/StylePortApp/AppSettings.swift` |
| iPhone 构建和 IPA 打包 | `.github/workflows/swift-port.yml` |
| Mac 本地构建 | `swiftPort/scripts/build-apple.sh` |

原生实现使用 SwiftUI、PhotoKit 和 VideoToolbox。现有核心可直接被新界面调用。
现有默认保存方式为另存新照片。

## 已运行的检查

环境：Linux x86_64、Python 3.12.14、Node.js 24.19.0。已执行 `uv sync --frozen`，
安装 Pillow 12.3.0 和 pillow-heif 1.5.0；系统提供 ffmpeg/libx265。

| 检查 | 本次结果 |
| --- | --- |
| Python CLI 版本与两个内置配置加载 | 通过 |
| 内置 Live Photo 视频模板加载 | 通过 |
| Web PWA 资源与离线清单检查 | 通过 |
| Web 中英文文案检查 | 通过，两个语言各 50 项 |
| `tests/graph.py` | 1 项纯逻辑检查通过；真实照片相关检查因样本缺失跳过 |
| `tests/soft_skin.py` | 2 项 plist 检查通过；真实人物照片相关检查因样本缺失跳过 |
| Swift 配置与 Python 内置配置逐项比较 | 两组一致，共 94 个 payload；ftyp、meta、MakerNote 也一致 |
| iOS Info.plist 解析、Mac 构建脚本语法 | 通过 |
| 自行生成 HEIC 的解码 | 通过，使用项目自带 heif-convert shim |
| 调用核心编码函数生成 HEVC Main10 缩略图 | 通过 |

生成样本的检查仅验证解码和编码组件。尚未执行真实 iPhone 照片的完整移植、
苹果相册中的调色板验证、Swift 单元测试或原生 APP 编译。

## 后续工作

已新增 `PhotoPickerScreen.swift` 和 `PhotoAdjustScreen.swift`，启动直接显示四列照片网格，
蓝色编号多选，底部“调整”进入预览；底部“导出”先保存新照片，再询问是否删除原图。
删除策略已补充 XCTest，但当前缺少 Swift/Xcode，测试尚未执行。
全部 32 个 Swift 源文件和测试文件已通过语法解析；该检查不等于 Apple API 类型检查。
新增 `scripts/package-ipa.sh`，供 macOS 环境测试、编译和打包。

完整实现和构建说明见 `swiftPort/README.custom.zh-CN.md`。

1. 在 Xcode 检查新界面与参考截图，并执行新增测试。
2. 使用用户提供的 HEIC 原图验证完整转换；实况照片还需要对应 MOV 文件。
3. 在具备 Xcode 的 macOS 环境运行 Swift 测试并编译 iPhone APP。
4. 打包 IPA，再完成安装签名和真机验证。

工程声明最低 iOS 17，构建文档要求 Xcode 16 或更新版本。当前环境没有
Swift、Xcode 或 iPhone 连接，暂不能验证上述原生步骤。

已有的未签名 IPA 也需要安装签名流程，不能作为点击文件即可直接安装的成品。
